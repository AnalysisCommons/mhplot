#' @name snpsOfInterest
#' @title snpsOfInterest
#' @docType data
NULL